import Foundation

var v1 = "Esto es Swift"
let c1 = 4
var cadena:String = String()
cadena = "Hola mundo " + v1
print("El contenido es: \(cadena)")
print("El valor de constante es: \(c1)")
